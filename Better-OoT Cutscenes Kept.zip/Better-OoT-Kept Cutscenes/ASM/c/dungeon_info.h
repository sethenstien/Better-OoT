#ifndef DUNGEON_INFO_H
#define DUNGEON_INFO_H

#include "z64.h"

void draw_dungeon_info(z64_disp_buf_t *db);

#endif
