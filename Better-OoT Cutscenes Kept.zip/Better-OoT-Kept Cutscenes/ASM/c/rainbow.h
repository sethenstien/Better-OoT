#ifndef _RAINBOW_H
#define _RAINBOW_H
#include <stdint.h>

void do_rainbow();
#endif